nome= input("digite seu nome:")

print("pazer", nome) 

ferias=input("oque voce fez de interresante nas ferias?:")



if ferias=="nada":
    print("que triste :(")

else:
    print("que bom, espero que tenha se divertido :)")

  