nome=input('Qual e o seu nome:')

print('ola', nome,)

a= input('tudo bem?:')

if a=='sim':
    print('que bom :)')

elif a=='nao':
    print('que coisa:(')

ferias= input("oque voce fez nas ferias?:")
print(ferias)

if 'viajei' in ferias or 'Viajei':
    print("CARAMBA, e pra aonde voce foi?")

elif 'futbol' in ferias or 'Futbol':
    print('CATAPIMBA!!!!, e quantos gols voce fez?')

elif  'li' in ferias or 'Li':
    print("UAU, isso e raro nos dias de hoje, e qual era o livro?")

elif  'descansei' in ferias or 'Descansei':
    print('BOA rsrsrs, e sempre bom descançar!!!')