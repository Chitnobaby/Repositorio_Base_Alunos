lista=['jose','otavio','jonathan','cristiane', 'manuela','gabriel']

for item  in lista:

    print("ola", item , "oque voce fez nas ferias?:")
    ferias= input ()

    print('entao voce', item, "fez", ferias, "!!!!")