lista=['maçã', 'banana', 'laranja']

lista.remove('banana')

print(lista)