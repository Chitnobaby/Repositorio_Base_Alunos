lista =[100, 200, 300, 400]

zeze=lista.pop(3)



print(zeze)