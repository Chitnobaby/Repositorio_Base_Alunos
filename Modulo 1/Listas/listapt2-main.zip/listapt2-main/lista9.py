
lista=[10,20,30,40,50]

lista.append(60)

lista.insert(1,15)

lista.remove(30)
print(lista)