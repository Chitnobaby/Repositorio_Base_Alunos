lista= ['python', 'java', 'c++']

techeteche= lista.pop(1)

print(lista)

print(techeteche)