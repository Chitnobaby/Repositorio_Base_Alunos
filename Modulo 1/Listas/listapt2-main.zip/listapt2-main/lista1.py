lista=[10,20,30]

lista.insert(1,15)


 
print(lista)