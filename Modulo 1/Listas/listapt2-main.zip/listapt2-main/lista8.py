lista =['a', 'b', 'd']

lista.insert(2,'c')

print(lista)

lista.remove('a')

print(lista)