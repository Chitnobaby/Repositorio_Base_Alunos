lista =[1, 2, 3, 4, 5]

lista.clear()

print(lista)