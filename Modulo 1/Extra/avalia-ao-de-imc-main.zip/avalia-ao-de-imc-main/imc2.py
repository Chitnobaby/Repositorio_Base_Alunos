#Aqui esta as variavels que usarei no meu codigo:)
nome=input('Digite o nome do paciente:')

peso=float(input('Digite seu peso em kg:'))

altura=float(input('Digite sua altura em metros:'))

imc=peso/ (altura*altura)



#Aqui definirei e irei descubrirei o imc :)
if imc<18.5:
    print(f"{nome}, tem o imc igual, {imc:.2},  e esta abaixo do peso")
    
elif imc<=24.9:
    print(f"{nome}, tem o imc igual, {imc:.2,}  e esta no peso adequado" )
    
elif imc<=29.9:
    print(f"{nome},  tem o imc igual, {imc:.2},  e esta sobre peso")
    
elif imc<=34.9:
    print(f"{nome} tem o imc igual, {imc:.2f}, e esta com obsidade de 1° grau")
    
elif imc<=39.9:
    print(f"{nome},tem o imc igual, {imc:.2f}  e esta com obsidade de 2° grau")
elif imc>=40.0:
    print(f"{nome },tem o imc igual, {imc:.2f}, e esta com obsidade de 3° grau" )
    
